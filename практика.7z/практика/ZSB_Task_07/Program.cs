﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZSB_Task_07
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество элементов массива: ");
            int n = Convert.ToInt32(Console.ReadLine());
            int[] mass = new int [n];
            Random rnd = new Random();
            for (int i = 0; i < n; i++)
            {
                mass[i] = rnd.Next(0, 100);
            }
            Console.WriteLine("Изначльный массив: " + string.Join(" ", mass));
            Shuffle(mass);
            Console.WriteLine("Измененный массив: " + string.Join(" ", mass));
            Console.ReadKey();
        }
        static void Shuffle<T>(IList<T> arr)
        {
            Random rnd = new Random();
            for (int i = 0; i < 100; i++)
            {
                var rnd1 = rnd.Next(0, arr.Count());
                var rnd2 = rnd.Next(0, arr.Count());
                var temp = arr[rnd1];
                arr[rnd1] = arr[rnd2];
                arr[rnd2] = temp;
            }
        }
    }
}
