﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime;

namespace ZSB_Task_06
{
    class Program
    {
        static void Main(string[] args)
        {
            int item = 0;
            while (item != 5)
            {
                Console.WriteLine("Отдел кадров:\n1 - добавить досье;\n2 - вывести все досье;\n3 - удалить досье;\n4 - поиск по фамилии;\n5 - выход из программы");
                Console.WriteLine("Выбирете пункт меню: ");
                item = Convert.ToInt32(Console.ReadLine());
                switch (item)
                {
                    case 1:
                        Console.WriteLine(Person.CreatePeople());
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 2:
                        Console.WriteLine(Person.GetAllInf());
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 3:
                        Console.WriteLine(Person.DelPeople());
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 4:
                        Console.WriteLine(Person.Search());
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 5:
                        break;
                    default:
                        Console.WriteLine("Введите корректный пункт меню");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                }
                    
            }
        }

    }

    public class Person
    {

        public static string[] AllInf = new string[10];
        public static string[] Position = new string[10];
        public static int i = 0;

        public static string CreatePeople()
        {
            Console.Write("Введите фамилию:");
            AllInf[i] = Console.ReadLine();
            Console.Write("Введите имя:");
            AllInf[i] += " " + Console.ReadLine();
            Console.Write("Введите отчество:");
            AllInf[i] += " " + Console.ReadLine();
            Console.Write("Введите должность:");
            Position[i] += " " + Console.ReadLine();
            i++;
            return "Человек добавлен в базу";
        }

        public static string GetAllInf()
        {
            for (int j = 0; j < AllInf.Length; j++)
            {
                Console.WriteLine(j+1 + ". Фио:" + AllInf[j] + "\nДолжность:" + Position[j]);
            }

            return "Все досье выведены";
        }

        public static string DelPeople()
        {
            Console.Write("Введите номер человека, которого хотите удалить:");
            int i = Convert.ToInt32(Console.ReadLine());
            AllInf[i - 1] = "Человек удален из базы";
            Position[i - 1] = "-";
            return "Человек удален из базы";
        }

        public static string Search()
        {
            Console.Write("Введите фамилию:");
            string Surname = Console.ReadLine();
            int item;
            string help;
            for(int j = 0; j < AllInf.Length; j++)
            {
                help = AllInf[j];
                for(int i = 0; i < Surname.Length; i++)
                {
                    if (help == null)
                    {
                        break;
                    }
                    else if (help[i] == Surname[i])
                    {
                        item = j;
                        Console.WriteLine(item + 1 + ".Фио:" + AllInf[item] + "\nДолжность: " + Position[item]);
                        break;
                    }
                }
            }
            return "Поиск выполнен";
        }
    }
}