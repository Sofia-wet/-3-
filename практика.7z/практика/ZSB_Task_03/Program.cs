﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZSB_Task_03
{
    class Program
    {
        static void Main(string[] args)
        {
            string password = "Yup";
            string input;
            for(int i = 0; i < 3; i++)
            {
                Console.Write("Введите пароль: ");
                input = Console.ReadLine();
                if (password == input)
                {
                    Console.WriteLine("Секретное сообщение:\nПРИВЕТ МИР!");
                    Console.ReadKey();
                    break;
                }
                else
                {
                    Console.WriteLine("Пароль неверный!\nВведите пароль еще раз!");
                }
            }
        }
    }
}
