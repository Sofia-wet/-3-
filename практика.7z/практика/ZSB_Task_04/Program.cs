﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZSB_Task_04
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            int hero = rnd.Next(500, 1001);
            int boss = rnd.Next(500, 1001);
            int move = rnd.Next(0, 2);
            int hit;
            string spell;
            Console.WriteLine("*******************");
            Console.WriteLine("Игра - БОЙ С БОССОМ");
            Console.WriteLine("*******************");
            Console.WriteLine("ПРАВИЛА ИГРЫ\n*Заклинания в арсенале игрока:*");
            Console.WriteLine("1. ПАУК - Пускает паутину. Сносит 80 едениц жизней");
            Console.WriteLine("*******************");
            Console.WriteLine("2. ЧЕЛОВЕК - Путает голову, тем самым нанося урон 10 едениц\n*Вызывает заклинание РУКА");
            Console.WriteLine("*******************");
            Console.WriteLine("3. РУКА - Наносит 50 едениц урона");
            Console.WriteLine("*******************");
            Console.WriteLine("4. УДАР - Супер-пупер удар -150 едениц урона");
            Console.WriteLine("*******************");
            Console.WriteLine("5. ЗДОРОВЬЕ - Исцеляет 50 едениц урона. Без возможности атаки");
            Console.WriteLine("*******************");
            Console.WriteLine("Начальное значение здоровья у игрока - {0} единиц", hero);
            Console.WriteLine("Начальное значение здоровья у БОССА - {0} единиц", boss);
            Console.WriteLine("*******************\n");
            Console.WriteLine("НАЧАЛО ИГРЫ!");
            Console.WriteLine("*******************\n");

            while(hero > 0 || boss > 0)
            {
                if (boss <= 0)
                {
                    Console.WriteLine("ВЫ ПОБЕДИЛИ БОССА\nПОЗДРАВЛЯЕМ!!!");
                    break;
                }
                else if (hero <= 0)
                {
                    Console.WriteLine("Вы проиграли\nПопробуйте еще раз!");
                    break;
                }

                if (move == 1)
                {
                    Console.WriteLine("АТАКУЕТ БОСС");
                    hit = rnd.Next(10, 151);
                    Console.WriteLine("Сила удара - {0}", hit);
                    hero -= hit;
                    Console.WriteLine("Значение здоровья у игрока - {0} единиц", hero);
                    Console.WriteLine("Значение здоровья у БОССА - {0} единиц", boss);
                    move = 0;
                    Console.WriteLine("\n*******************");
                    hit = 0;
                }
                else
                {
                    Console.WriteLine("АТАКУЕТ Игрок");
                    Console.Write("Введите заклинание(Цифру)");
                    spell = Console.ReadLine();
                    hit = 0;
                    switch (spell)
                    {
                        case "1":
                            Console.WriteLine("Заклинание: ПАУК");
                            hit = 80;
                            Console.WriteLine("Сила удара - {0}", hit);
                            break;
                        case "2":
                            Console.WriteLine("Заклинание: ЧЕЛОВЕК");
                            hit = 10;
                            Console.WriteLine("Сила удара - {0}", hit);
                            goto case "3";
                        case "3":
                            Console.WriteLine("Заклинание: РУКА");
                            hit = 50;
                            Console.WriteLine("Сила удара - {0}", hit);
                            break;
                        case "4":
                            Console.WriteLine("Заклинание: УДАР");
                            hit = 150;
                            Console.WriteLine("Сила удара - {0}", hit);
                            break;
                        case "5":
                            Console.WriteLine("Заклинание: ЗДОРОВЬЕ");
                            hero += 50;
                            Console.WriteLine("Вы исцелились на 50 едениц");
                            break;
                        default:
                            Console.WriteLine("Вы не знаетете {0} это заклинания или вы произнесли его не правильно.", spell);
                            break;
                    }
                    boss -= hit;
                    Console.WriteLine("Значение здоровья у игрока - {0} единиц", hero);
                    Console.WriteLine("Значение здоровья у БОССА - {0} единиц", boss);
                    move = 1;
                    Console.WriteLine("\n*******************");
                    hit = 0;
                }
            }
            
            Console.ReadKey();
        }
    }
}
