﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZSB_Task_01
{
    class Program
    {
        static void Main(string[] args)
        {
            int gold = 0; string gold1;
            int price = 2;
            int crystal = 0;
            int sum; string sum1;
            bool test = false;
            while (test == false)
            {

                Console.Write("Введите начальное кол-во золота: ");
                gold1 = Console.ReadLine();
                Console.WriteLine("\n----------------------------------------------------------");
                Console.WriteLine("В магазине есть кристаллы на продажу.\n Цена за один кристалл - " + price + ".");
                Console.WriteLine("Сколько кристалов вы хотите купить?");
                sum1 = Console.ReadLine();
                try
                {
                    gold = Convert.ToInt32(gold1);
                    sum = Convert.ToInt32(sum1);
                    while (sum > 0 && gold > sum * price)
                    {
                        crystal += 1;
                        sum--;
                        gold -= price;
                    }
                    test = true;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Что-то не то))\nПопробуй сначала)\n\n");
                }
            }
            Console.WriteLine("Золото {0}, Кристалы {1}, Цена {2}", gold, crystal, price);
            Console.ReadKey();
        }
    }
}
